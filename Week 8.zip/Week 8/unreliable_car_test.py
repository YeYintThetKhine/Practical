from prac_08.unrelaible_car import UnreliableCar

def main():
    car = UnreliableCar("Car", 100, 30)
    car.drive(110)
    print(car)


main()

