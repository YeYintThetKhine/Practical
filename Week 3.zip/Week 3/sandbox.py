x= 2.36*10
print(x)
print("{0:.1f}".format(x))